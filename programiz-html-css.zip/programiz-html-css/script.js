<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            text-align: center;
            background-color: #f4f4f4;
        }
        header {
            background: #333;
            color: white;
            padding: 20px;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 15px;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
        }
        section {
            padding: 20px;
        }
        form input, form textarea {
            display: block;
            width: 80%;
            margin: 10px auto;
            padding: 10px;
        }
        form button {
            background: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to My Website</h1>
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    
    <section id="home">
        <h2>Home</h2>
        <p>This is the homepage of our awesome website.</p>
    </section>
    
    <section id="about">
        <h2>About Us</h2>
        <p>We provide amazing web development services.</p>
    </section>
    
    <section id="services">
        <h2>Our Services</h2>
        <p>We offer website development, SEO, and digital marketing.</p>
    </section>
    
    <section id="contact">
        <h2>Contact Us</h2>
        <form id="contactForm">
            <input type="text" id="name" placeholder="Your Name" required>
            <input type="email" id="email" placeholder="Your Email" required>
            <textarea id="message" placeholder="Your Message" required></textarea>
            <button type="submit">Send Message</button>
        </form>
        <p id="formResponse" style="color: green; display: none;">Message sent successfully!</p>
    </section>
    
    <script>
        document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault();
            document.getElementById("formResponse").style.display = "block";
            setTimeout(() => {
                document.getElementById("formResponse").style.display = "none";
            }, 3000);
            document.getElementById("contactForm").reset();
        });
    </script>
</body>
</html>
